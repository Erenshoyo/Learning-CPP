#include<iostream>
#include "binarysearchtree.cpp"
using namespace std;

/*void balanced(TreeType<int> &balance, int arr[], int l, int r)
{
    if ( l > r) return ;

    int mid = (l + r) / 2;

    balance.InsertItem(arr[mid]);

    balanced(balance, arr, l, mid - 1);
    balanced(balance, arr, mid + 1, r);
}

int main()
{
    TreeType<int> tree, balance;

    int temp, i = 0;
    bool finished = false;
    int arr[10];

    for(int i = 0; i < 10; i++)
    {
        cin >> temp;
        tree.InsertItem(temp);
    }

    tree.ResetTree(IN_ORDER);
    while(!finished)
    {
        tree.GetNextItem(temp, IN_ORDER, finished);
        arr[i++] = temp;
    }

    //for (int i : arr) cout << i << " ";
    for(int i = 0; i < 10; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    balanced(balance, arr, 0, 9);

    finished = false;

    balance.ResetTree(PRE_ORDER);

    while(!finished)
    {
        balance.GetNextItem(temp, PRE_ORDER, finished);
        cout << temp << " ";
    }

    cout << endl;

    return 0;
}*/

int main()
{
    TreeType<int> tree;
    cout<<(tree.IsEmpty()? "Empty":"Not Empty")<<endl;
    int arr[] = {4, 9, 2, 7, 3, 11, 17, 0, 5, 1};
    for(int i:arr) tree.InsertItem(i);
    cout<<(tree.IsEmpty()? "Empty":"Not Empty")<<endl;
    cout<<tree.LengthIs()<<endl;
    int val=9;
    bool isFound=false;
    tree.RetrieveItem(val, isFound);
    cout<<(isFound? "Found":"Not found")<<endl;
    int val1=13;
    bool isFound1=false;
    tree.RetrieveItem(val1, isFound1);
    cout<<(isFound1? "Found":"Not found")<<endl;
    {
        int temp;
        bool isFinished=false;
        tree.ResetTree(PRE_ORDER);
        while(!isFinished)
        {
            tree.GetNextItem(temp, PRE_ORDER, isFinished);
            cout<<temp<<" ";
        }
        cout<<endl;
    }
    {
        int temp;
        bool isFinished=false;
        tree.ResetTree(IN_ORDER);
        while(!isFinished)
        {
            tree.GetNextItem(temp, IN_ORDER, isFinished);
            cout<<temp<<" ";
        }
        cout<<endl;
    }
    {
        int temp;
        bool isFinished=false;
        tree.ResetTree(POST_ORDER);
        while(!isFinished)
        {
            tree.GetNextItem(temp, POST_ORDER, isFinished);
            cout<<temp<<" ";
        }
        cout<<endl;
    }
    tree.MakeEmpty();
    cout<<tree.LengthIs()<<endl;
    return 0;
}

