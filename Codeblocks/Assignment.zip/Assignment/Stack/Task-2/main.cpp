#include <iostream>
#include <string>
#include "StackType.cpp" // Include your stack implementation

using namespace std;

int main() {
    string s;
    cout << "Enter parentheses sequence: ";
    cin >> s;

    StackType<char> stack;
    int currentDepth = 0, maxDepth = 0;

    for (char c : s) {
        if (c == '(') {
            stack.Push(c); // push into stack
            currentDepth++;
            if (currentDepth > maxDepth)
                maxDepth = currentDepth;
        }
        else if (c == ')') {
            stack.Pop(); // remove from stack
            currentDepth--;
        }
    }

    cout << "Maximum Depth: " << maxDepth << endl;
    return 0;
}
