#include <iostream>
#include <string>
#include "StackType.cpp"

using namespace std;

int main() {
    string expr;
    cout << "Enter a postfix expression: ";
    getline(cin, expr);

    StackType<int> stack;
    int n = expr.length();
    bool invalid = false;

    int i = 0;
    while (i < n) {
        char ch = expr[i];

        // Skip spaces
        if (ch == ' ') {
            i++;
            continue;
        }

        // Handle numbers (multi-digit or negative)
        if ((ch >= '0' && ch <= '9') ||
            (ch == '-' && i+1 < n && expr[i+1] >= '0' && expr[i+1] <= '9')) {

            bool negative = false;
            if (ch == '-') {
                negative = true;
                i++;
            }

            int num = 0;
            while (i < n && expr[i] >= '0' && expr[i] <= '9') {
                num = num * 10 + (expr[i] - '0');
                i++;
            }
            if (negative) num = -num;

            try { stack.Push(num); }
            catch (FullStack) { invalid = true; break; }

            continue;
        }

        // Handle operators
        if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            if (stack.IsEmpty()) { invalid = true; break; }
            int b = stack.Top(); stack.Pop();
            if (stack.IsEmpty()) { invalid = true; break; }
            int a = stack.Top(); stack.Pop();

            int res;
            if (ch == '+') res = a + b;
            else if (ch == '-') res = a - b;
            else if (ch == '*') res = a * b;
            else {
                if (b == 0) { invalid = true; break; }
                res = a / b;
            }

            try { stack.Push(res); }
            catch (FullStack) { invalid = true; break; }

            i++;
            continue;
        }

        // Invalid character
        invalid = true;
        break;
    }

    // Final result check
    if (!invalid && !stack.IsEmpty()) {
        int result = stack.Top();
        stack.Pop();
        if (!stack.IsEmpty()) invalid = true;
        else cout << "Result: " << result << endl;
    }

    if (invalid) cout << "Invalid expression" << endl;

    return 0;
}
