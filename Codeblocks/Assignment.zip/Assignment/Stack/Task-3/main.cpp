#include <iostream>
#include "stacktype.cpp"
using namespace std;

int main() {
    StackType<int> st;
    StackType<int> temp;

    int n = 4;

    cout << "Insert the values to be added to stack: " << endl;
    for (int i = 0; i < n; i++) {
        int item;
        cin >> item;

        while (!st.IsEmpty() && st.Top() > item) {
            temp.Push(st.Top());
            st.Pop();
        }

        st.Push(item);

        while (!temp.IsEmpty()) {
            st.Push(temp.Top());
            temp.Pop();
        }

        StackType<int> restore;
        while (!st.IsEmpty()) {
            cout << st.Top() << " ";
            restore.Push(st.Top());
            st.Pop();
        }
        cout << endl;

        while (!restore.IsEmpty()) {
            st.Push(restore.Top());
            restore.Pop();
        }

        cout << endl;
    }

    return 0;
}
